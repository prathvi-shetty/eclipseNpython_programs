from kafka import KafkaConsumer
from json import loads
import re
import unicodedata
import configparser
import ast
import praw
from pprint import  pprint
import  pandas as pd
import  datetime as dt
import json
from textblob import TextBlob
import os
with open('reddit-credt.json') as f:
   creds = json.load(f)
config = configparser.ConfigParser()
config.read('configuration.ini')
fdi_subreddit_india = ["IndiaInvestments","India","IndiaSpeaks","indianews","AutoNewsPaper"]
consumer = KafkaConsumer(
    'keyword',
     bootstrap_servers=['localhost:9092'],
     auto_offset_reset='latest',
     enable_auto_commit=True,
     group_id='my-group',
     value_deserializer=lambda x: loads(x.decode('utf-8')))
def data_clean(text):
    # data cleaning
    title = str(text)

    # removing square bracket and conents inside it
    title = re.sub(r'\[.*?\]', '', title)

    # removing bracket and conents inside it
    title = re.sub(r'\(https?.*?\)', '', title)

    # removing url links
    title = re.sub('https?://[A-Za-z0-9./]+', '', title)

    # replacing speacial character with ''
    title = re.sub('[^\w\s]', '', title)

    # removing chinese character
    title = re.sub(r'[^\x00-\x7f]', r'', title)

    # removing accented characters
    title = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('utf-8', 'ignore')

    # removing newline
    title = re.sub(r'\n', '', title)
    # print(title)
    return title


def detect_polarity(text):
    return TextBlob(text).sentiment.polarity

def save_to_csv(type_posts,key):
    posts = []
    country = 'India'
    for post in type_posts:
        # title = data_translation(post.title)
        title = data_clean(post.title)
        polarity = detect_polarity(title)
        if(len(title)>0):
            posts.append([title, post.score, (post.upvote_ratio * 100), post.id,post.url, post.num_comments, (dt.date.fromtimestamp(post.created)),post.subreddit,polarity,key,country])

    post = pd.DataFrame(posts,columns=['title','score','upvote_ratio','id','url','num_comments','created','subreddit','post_polarity_textblob','topic','country'])
    pprint(post)
    if not os.path.isfile('fdi_related_india_5nov.csv'):
        post.to_csv('fdi_related_india_5nov.csv', header= True, index=False)
    else:  # else it exists so append without writing the header
        post.to_csv('fdi_related_india_5nov.csv', mode='a', header=False ,index=False)
reddit = praw.Reddit(client_id  = creds['client_id'],client_secret = creds['client_secret'],user_agent = creds['user_agent'])
def search_by_key (key):
    for ele in fdi_subreddit_india:
        subreddit = reddit.subreddit(ele)
        type_posts = subreddit.search(key,limit = None,sort='relevance',time_filter='year')
        save_to_csv(type_posts,key)



for message in consumer:
    message = message.value
    print(message)
    search_by_key(message)
    print(message)

