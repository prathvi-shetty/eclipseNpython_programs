# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 16:25:22 2019

@author: prathvi.shetty
"""

import re
import textblob
from bs4 import BeautifulSoup
import pandas as pd
import requests
import datetime
from newsapi import NewsApiClient
import string
import ast
import boto3
from nltk.corpus import stopwords
from nltk.tokenize import regexp_tokenize
from nltk.stem import WordNetLemmatizer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import configparser

# To create a stopwords list having all stopwords from the stopwords.word library along with the same stopwords having
# first letter capitalised
stopword = stopwords.words('english')
capital_stop_words = list(map(lambda x: x.capitalize(), stopwords.words('english')))
stopword = stopword + capital_stop_words

config = configparser.ConfigParser()
config.read('configuration.ini')
x = config['news']['api_key']
default_sources = config['news']['default_sources']
default_domain = config['news']['default_domain']
start_date = config['news']['start_date']
to_date = config['news']['to_date']
key_words_in_string = config['news']['keywords_saudi']
keywords = ast.literal_eval(key_words_in_string)
UIkeywords_in_string = config['news']['UIkeywords_saudi']
UIkeywords = ast.literal_eval(UIkeywords_in_string)
tecountry = config['news']['tecountry']
sources_in_string = config['news']['sources_saudi']
sources = ast.literal_eval(sources_in_string)
domains_in_string = config['news']['domains_saudi']
domains = ast.literal_eval(domains_in_string)
extra_source = config['news']['extra_source']
country = config['news']['country']


# NEWSAPI class to get news from different sources
class NEWSAPI:

    # to authenticate the NEWSAPI
    def __init__(self):
        self.api = NewsApiClient(api_key= x)

    # to get only the top headlines of the given keyword from specified sources
    '''def top_headlines(self):
        return self.api.get_top_headlines(q='trump', category='business', sources='bbc-news,the-verge',
                                          language='en', country='us')'''

    # to get everything related to the given keyword from specified sources
    def everything(self, keyword, source= default_sources,
                   domain=default_domain):
        return self.api.get_everything(q=keyword, sources=source, domains=domain
                                       , from_param=start_date, to=to_date, language='en', sort_by='relevancy')

    # to get the sources p
    def sources(self):
        return self.api.get_sources()


class DataCleaning:
    # Method to remove the punctuations in the text
    def remove_punctuation(text):
        exclude = set(string.punctuation)
        no_punc = ''.join(ch for ch in text if ch not in exclude)
        return no_punc.lower()

    # Method to remove the STOPWORDS from the text
    def remove_stopwords(text):
        words = [w for w in text if w not in stopword]
        return words

    # Method to perform LEMMATISATION on the text
    def word_lemmatizer(text):
        lem_text = [WordNetLemmatizer().lemmatize(i) for i in text]
        return lem_text


def list_keyword(article):
    empty_list = []
    list_of_words = article.split(' ')
    lower_case_list_of_words = [word.lower() for word in list_of_words]
    for UIkey in UIkeywords:
        for key in UIkey:
            if key in lower_case_list_of_words:
                empty_list.append(UIkey[0])
                break
    if empty_list==[]:
        empty_list.append('Others')
    return empty_list


# Variable used for Calling NEWSAPI to get the news articles related to the keyword
apicall = NEWSAPI()

# lists to store the details of the articles
source_keyword, source_name, source_country, source_topic, source = [], [], [], [], []
description, publishedAt, source_id, body, title, url = [], [], [], [], [], []
textblob_sentiment, vader_sentiment = [], []

# SAUdi
'''keywords = ['economy of saudi', 'GDP of saudi', 'imports of saudi', 'exports of saudi', 'unemployment in saudi', 'SAMA',
             'ARAMCO', 'SABIC', 'saudi riyal', 'tadawul', 'saudi crude oil', 'saudi SAR', 'saudi petroleum', 'riyadh']
UIkeywords = [['GDP', 'gdp', '(gdp)'], ['Imports_and_Exports', 'import', 'imports', 'export', 'exports'],
               ['Unemployment', 'unemployed', 'unemployment'], ['Aramco', 'aramco'], ['SABIC', 'sabic'],
               ['SAMA', 'sama'], ['ICT_services', 'ict'], ['Riyal', 'riyal', 'currency'],
               ['Oil', 'crude', 'petrol', 'petroleum', 'crude-oil'], ['Stock_Exchange', 'stock', 'tadawul'],
               ['Economy', 'economy', 'economies', 'economic', 'economist']]
country = 'SAUDI'
tecountry='saudi-arabia'
sources = ["reuters", 'al-jazeera-english', 'bbc-news']
domains = ["www.reuters.com", 'aljazeera.com', 'bbc.co.uk/news']'''

# UK
#keywords = ['economy of UK', 'GDP of UK', 'imports of UK', 'exports of UK', 'unemployment in UK', 'theresa may',
#            'boris jhonson', 'GBP', 'UK monetory policy', 'Euronext', 'London Stock Exchange Group', 'brexit']
#UIkeywords = [['GDP', 'gdp', '(gdp)'], ['Imports_and_Exports', 'import', 'imports', 'export', 'exports'], ['Brexit'],
#              ['Unemployment', 'unemployed', 'unemployment'], ['Theresa_May', 'theresa'], ['Boris_Jhonson', 'boris'],
#              ['Pound', 'gbp', 'currency'], ['Stock_Exchange', 'stock', 'stocks'], ['Euro'], ['Technology'], ['cpi'],
#              ['Euronext'], ['Economy', 'economy', 'economies', 'economic', 'economist']]
#country = 'UK'
#tecountry = 'united-kingdom'
#sources = ["reuters", 'bbc-news']
#domains = ["http://www.reuters.com", 'bbc.co.uk/news']

# india
#keywords = ['economy of india', 'GDP of india', 'exports of india', 'imports of india', 'unemployment in india',
#            'modi', 'rupee', 'nirmala seetharaman', 'BSE', 'NSE', 'RBI', 'NIFTY', 'GST', 'recession in india']
#UIkeywords = [['GDP', 'gdp', '(gdp)'], ['Imports_and_Exports', 'import', 'imports', 'export', 'exports'],
#              ['Unemployment', 'unemployed', 'unemployment'], ['Inflation'], ['budget'], ['Modi', 'modi'],
#              ['Rupee', 'rupee', 'currency'], ['Nirmala_Seetharaman', 'seetharaman'], ['BSE', 'bse'], ['NSE', 'nse'],
#              ['NIFTY', 'nifty', 'stock exchange', 'stocks', 'stock'], ['GST', 'gst'], ['RBI', 'rbi'], ['Recession'],
#              ['Economy', 'economy', 'economies', 'economic', 'economist']]
#country = 'INDIA'
#tecountry = 'india'
#sources = ["reuters", 'the-hindu']
#domains = ["http://www.reuters.com", 'http://www.thehindu.com']

# US
# keywords = ['economy of US', 'GDP of US','imports of US', 'exports of US', 'unemployment in US', 'donald trump',
#             'US dollar', 'mnuchin', 'US treasury', 'affordable care act', 'US elections', 'New York Stock Exchange',
#             'NASDAQ','nyse']
# UIkeywords=[['GDP','gdp','(gdp)'],['Imports_and_Exports','import','imports','export','exports'],
#            ['Unemployment','unemployed','unemployment'],['Donald_trump','trump'],['Elections','elections','election'],
#            ['Steven_Mnuchin','mnuchin'],['Dollar','currency','dollar'],['Treasury','treasury'],
#            ['Stock_exchange','stocks','stock','nyse','wto','stockexchange'],['Technology'],
#            ['Economy','economy', 'economies', 'economic', 'economist']]
# country = 'US'
# tecountry = 'united-states'
# sources = ["reuters", 'abc-news','fox-news','bbc-news']
# domains = ["http://www.reuters.com", "https://abcnews.go.com", 'foxnews.com','bbc.co.uk/news']


# Source ID's and Domain URL's of all the following news sources
# sources = ['abc-news']'bbc-news', 'al-jazeera-english','the-hindu','daily-mail','new-york-magazine','abc-news',
#            'reuters','fox-news'
# domains = ['bbc.co.uk/news']'bbc.co.uk/news', 'aljazeera.com','http://www.thehindu.com',
#            'http://www.dailymail.co.uk/home/index.html','http://nymag.com',"https://abcnews.go.com",
#            'http://www.reuters.com','foxnews.com'


# To get the data for all the keywords
for keyword in keywords:
    # Creating lists to append the required values from the coming response
    for source_no in range(len(sources)):
        response = apicall.everything(keyword, sources[source_no], domains[source_no])
        for article in response["articles"]:
            description.append(article["description"])
            publishedAt.append(datetime.datetime.strptime(
                datetime.datetime.strptime(article["publishedAt"][:10], '%Y-%m-%d').strftime('%d/%m/%y'), '%d/%m/%y'))
            source_id.append(article["source"]["id"])
            source_name.append(article["source"]["name"])
            title.append(article["title"])
            url.append(article["url"])
        print(keyword, sources[source_no], len(response["articles"]))
print(len(url))

# Extracting the main article from the URL obtained from the response of NEWSAPI
for i in range(len(url)):
    string = str(url[i])
    html = requests.get(string)
    soup = BeautifulSoup(html.text, 'html.parser')
    if source_id[i] == 'new-york-magazine':
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'article-content'})
    elif source_id[i] == "reuters":
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'StandardArticleBody_body'})
    elif source_id[i] == 'daily-mail':
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'itemprop': 'articleBody'})
    elif source_id[i] == 'abc-news':
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'article-copy'})
    elif source_id[i] == 'the-hindu':
        print('Entracting from ' + source_id[i])
        cls_name = 'content-body-14269002-' + string[-12:-4]
        cur = soup.find('div', {'id': cls_name})
    elif source_id[i] == 'fox-news':
        fox = 1
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'article-body'})
    elif source_id[i] == 'bbc-news':
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'story-body__inner'})
    elif source_id[i] == 'al-jazeera-english':
        print('Entracting from ' + source_id[i])
        cur = soup.find('div', {'class': 'article-p-wrapper'})
    main = ''
    try:
        for p in cur.find_all('p'):
            if source_id[i] == 'fox-news' and fox == 1:
                fox = 0
                continue
            for sent in ['Associated Press', 'Watch | ', '| Photo Credit: ', 'Photo by', "GET THE FOX NEWS APP",
                         "HERE FOR THE ALL NEW", "HERE TO SIGN UP FOR OUR LIFESTYLE ",
                         "**Want FOX News Halftime Report in your inbox every day? Sign up here.**",
                         "HERE TO READ MORE FROM SALLY "]:
                if sent in p.text:
                    continue
            main = main + p.text.strip()
            pIN = p.find_all('p')
            if pIN:
                main = main + pIN.text.strip()
        main = re.sub('[^A-Za-z.,1234567890 ]+', '', main)
        body.append(main)

    except AttributeError:
        main = 'NULL'
        body.append(main)
    except ConnectionError:
        main = 'NULL'
        body.append(main)
print('NEWSAPI is DONE')

# Trading Economics Extration Code
html = requests.get(extra_source + tecountry + '/news')
soup = BeautifulSoup(html.text, 'html.parser')
cur = soup.find('table', {'id': 'ctl00_ContentPlaceHolder1_ctl01_DataListRelatedNews'})
x, y = 1, 0
for tr in cur.find_all('tr'):
    if x == 1:
        x = x - 1
        continue
    if y > 400:
        break
    y += 1
    publishedAt.append(
        datetime.datetime.strptime('-'.join(tr.find_all('td')[0].find_all('small')[0].string.split(' ')[1:]),
                                   '%B-%d-%Y'))
    url.append(
        'https://tradingeconomics.com/' + tecountry + '/' + tr.find_all('td')[0].find_all('a')[0]['href'].split('/')[
            -1])
    title.append(tr.find_all('td')[0].find_all('a')[0].string.strip())
    # description.append(tr.find_all('td')[0].find_all('div')[0].string.strip())
    content = tr.find_all('td')[0].find_all('div')[0].string.strip()
    content = re.sub('[^A-Za-z.,1234567890 ]+', '', content)
    description.append(content)
    body.append(content)
    source_name.append('Trading Economics')
print('TRADING ECONOMICS is DONE')

# Removing records having Main body column with null values
null = []
for i in range(len(body)):
    if body[i] == 'NULL':
        null.append(i)
null.reverse()
for i in null:
    i = int(i)
    del description[i]
    del publishedAt[i]
    # del source_id[i]
    del source_name[i]
    del title[i]
    del url[i]
    del body[i]
print(len(description), len(publishedAt), len(source_name), len(title), len(url), len(body))

# Creating a dataframe
# dict = {'Topic/Keyword' : topic,'Author': author, 'Description': description, 'Date': publishedAt,
#         'Source_id': source_id,'Source_name': source_name, 'Title': title, 'URL': url, 'Main_Body': body}
data = {'Date': publishedAt, 'News_source': source_name, 'url': url, 'Title': title, 'Description': description,
        'Main_Body': body}
df = pd.DataFrame(data)

# "Main_Body_no_char" is a column which has the main body of the article removing unnecessary special characters
df["Main_Body_no_char"] = df["Main_Body"].apply((lambda x: " ".join(regexp_tokenize(x, r'\w+'))))

# "LEMM_Main_Body" is a column which has the list of lemmatised words present in the main body of the article
df["LEMM_Main_Body"] = df["Main_Body"].apply((lambda x: regexp_tokenize(x, r'\w+')))
df["LEMM_Main_Body"] = df["LEMM_Main_Body"].apply((lambda x: DataCleaning.remove_stopwords(x)))
df["LEMM_Main_Body"] = df["LEMM_Main_Body"].apply((lambda x: DataCleaning.word_lemmatizer(x)))

# "Keywords" is a column which has the list of keywords present in the main body of the article
df["Keywords"] = df['Main_Body'].apply(lambda x: list_keyword(x))

# De-duplication of dataframe using "Title" column
df.drop_duplicates(subset="Title", keep="first", inplace=True)

# "text_blob_sentiment" and "Vader_sentiment" are the columns having the sentiment values of the "Main_Body_no_char"
# column using respective libraries
for text in df["Main_Body_no_char"]:
    textblob_sentiment.append(textblob.TextBlob(text).sentiment[0])
    vader_sentiment.append(SentimentIntensityAnalyzer().polarity_scores(text)["compound"])
df["text_blob_sentiment"] = textblob_sentiment
df["Vader_sentiment"] = vader_sentiment
print('SENTIMENT IS DONE')

# 'Country', 'Topic', 'Source' are the columns which give specific details of country,topic and source of the article
rows = df.shape[0]
for i in range(rows):
    source_topic.append('FDI')
    source_country.append('Saudi')
    source.append('News')
df['Country'] = source_country
df['Source'] = source
df['Topic'] = source_topic

# Droping the "Main_Body_no_char" column in the dataframe as it is no longer required
df.drop("Main_Body_no_char", axis=1, inplace=True)
print(" data is Cleaned & Validated")

# Finally, Tranfering the dataframe to a CSV file for further process
df.to_csv(country + '_economy_data_today.csv')


# To add the extracted CSV files to S3 bucket
#s3 = boto3.client('s3')
#s3.upload_file(country + '_economy_data.csv','rawdata-sentiment-analysis',country + '_economy_data.csv')
#print('UPLOADED')