from json import dumps
from time import sleep
from kafka import KafkaConsumer
import flask
from flask import request, jsonify
from flask_cors import CORS, cross_origin
from kafka import KafkaProducer
app = flask.Flask("__main__")
CORS(app)

keywords = []



@app.route('/api', methods=['POST', 'GET'])
@cross_origin()
def api_post():
    if request.method == 'POST':
        global keywords
        print('post app')

        req = request.args['keyword']
        producer = KafkaProducer(bootstrap_servers=['localhost:9092'],
                                 value_serializer=lambda x:
                                 dumps(x).encode('utf-8'))
        producer.send('keyword', value= req)
        print(req)
        keywords.append(req)
        with open("configuration.ini", "a") as output:
            output.write("keyword = "  + str(keywords))
        return req

app.run(host = '0.0.0.0', threaded=True  )