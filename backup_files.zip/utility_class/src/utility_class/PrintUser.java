package utility_class;
import java.util.TimerTask;

public class PrintUser extends TimerTask {
    private int i=0;
    public void run() {
    	System.out.println("Hello" + i);
    	i++;
    }
}
