package utility_class;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
public class utility1 {
	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);
		Date date1 = new Date(System.currentTimeMillis());
		System.out.println(date1);
		System.out.println(date1.compareTo(date));
		Locale loc = new Locale("Hindi","IN");
		System.out.println(loc.getLanguage());
		System.out.println(loc.getCountry());
		System.out.println(loc.getISO3Country());
		
		
	}

}
