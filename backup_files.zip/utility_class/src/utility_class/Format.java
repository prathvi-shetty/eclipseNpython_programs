package utility_class;
import java.util.Formatter;

public class Format {

	   public static void main(String[] args) {
		   Formatter format = new Formatter();
		   formatter.format("%S");
	   }
}
