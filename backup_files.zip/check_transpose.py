import pandas as pd
df = pd.read_csv('twitter_sort_1.csv')

df.to_csv("twitter_sort_1_trial.csv",index = False,header = False)
pd.read_csv('twitter_sort_1_trial.csv', header=None).T.to_csv('twitter_sort_1_trial1.csv', header=False, index=False)
df = pd.read_csv('twitter_sort_1_trial1.csv')

for q in range(0, df.shape[0]):
    df = df.dropna(axis=0, how='any')

df.to_csv("twitter_sort_1_trial2.csv")