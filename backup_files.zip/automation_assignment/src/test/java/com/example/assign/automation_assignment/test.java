package com.example.assign.automation_assignment;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class test {


	@Test
    public  void method1() throws InterruptedException
    {
    	WebDriver driver ;
       
    	System.setProperty("webdriver.gecko.driver","C:\\Users\\prathvi.shetty\\Downloads\\geckodriver-v0.25.0-win64\\geckodriver.exe");
		 driver = new FirefoxDriver();
   	
      
   		driver.manage().window().maximize();		
           String baseUrl = "file:///C:/Users/prathvi.shetty/Downloads/AutomationTask/ForSession/sample.html";
            
            // launch Fire fox and direct it to the Base URL
            driver.get(baseUrl);
           WebElement textbox=driver.findElement(By.id("user-message"));
           textbox.sendKeys("Welcome");
           Thread.sleep(1000);
           
           WebElement button=driver.findElement(By.id("btn-default"));
           button.click();
           Thread.sleep(1000);
           
           WebElement checkBox=driver.findElement(By.id("isAgeSelected"));
           checkBox.click();
           Thread.sleep(1000);
           
           WebElement radioButton=driver.findElement(By.xpath("//*[contains(text(),'Male')]"));
           radioButton.click();
           Thread.sleep(1000);
         
           
           WebElement buttonCheck=driver.findElement(By.id("buttoncheck"));
           buttonCheck.click();
           
           WebElement drop=driver.findElement(By.xpath("//*[contains(text(),'Wednesday')]"));
           drop.click();
           Thread.sleep(1000);
           
           
    }
	    
}
