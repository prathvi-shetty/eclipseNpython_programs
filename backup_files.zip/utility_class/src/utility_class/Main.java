package utility_class;
import java.util.Date;
import java.util.Timer;
public class Main {
    public static void main(String[] args) {
    	Timer timer = new Timer();
    	PrintUser printUser = new PrintUser();
    	PrintUser printUser2 = new PrintUser();
    	timer.schedule(printUser, 1000,1999);
    	timer.scheduleAtFixedRate(printUser, new Date(), 1000); 
    }
   
    }

