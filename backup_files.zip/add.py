import luigi
import configparser
import re
import subprocess
import unicodedata
import ast
import praw
from pprint import  pprint
import  pandas as pd
import  datetime as dt
import json
from textblob import TextBlob
import os

class Add(luigi.Task):

    def output(self):
        return luigi.LocalTarget('saudi_related_topics_5.csv')
    def run(self):
        with open('reddit-credt.json') as f:
            creds = json.load(f)
        config = configparser.ConfigParser()
        config.read('configuration.ini')

        reddit = praw.Reddit(client_id=creds['client_id'], client_secret=creds['client_secret'],
                             user_agent=creds['user_agent'])

        FDI_keywords_in_string = config['reddit']['fdi_keywords_saudi']
        FDI_keywords = ast.literal_eval(FDI_keywords_in_string)

        saudi_fdi_subreddit_in_string = config['reddit']['fdi_subreddit_saudi']
        saudi_fdi_subreddit = ast.literal_eval(saudi_fdi_subreddit_in_string)

        def listToString(s):
            str1 = "+"
            str1 = str1.join(s)
            return str(str1)

        # function to save into csv file
        def save_to_csv(type_posts, key):
            posts = []
            country = 'Saudi'
            for post in type_posts:
                # title = data_translation(post.title)
                title = data_clean(post.title)
                polarity = detect_polarity(title)
                if (len(title) > 0):
                    posts.append([title, post.score, (post.upvote_ratio * 100), post.id, post.url, post.num_comments,
                                  (dt.date.fromtimestamp(post.created)), post.subreddit, polarity, key, country])

            post = pd.DataFrame(posts,
                                columns=['title', 'score', 'upvote_ratio', 'id', 'url', 'num_comments', 'created',
                                         'subreddit', 'post_polarity_textblob', 'topic', 'country'])
            pprint(post)
            if not os.path.isfile('saudi_related_topics_5.csv'):
                post.to_csv('saudi_related_topics_5.csv', header=True, index=False)
            else:  # else it exists so append without writing the header
                post.to_csv('saudi_related_topics_5.csv', mode='a', header=False, index=False)

        # function to do the data cleaning
        def data_clean(text):
            # data cleaning
            title = str(text)

            # removing square bracket and conents inside it
            title = re.sub(r'\[.*?\]', '', title)

            # removing bracket and conents inside it
            title = re.sub(r'\(https?.*?\)', '', title)

            # removing url links
            title = re.sub('https?://[A-Za-z0-9./]+', '', title)

            # replacing speacial character with ''
            title = re.sub('[^\w\s]', '', title)

            # removing chinese character
            title = re.sub(r'[^\x00-\x7f]', r'', title)

            # removing accented characters
            title = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('utf-8', 'ignore')

            # removing newline
            title = re.sub(r'\n', '', title)
            # print(title)
            return title

        def detect_polarity(text):
            return TextBlob(text).sentiment.polarity

        # function to get the posts on the basis of entered keywords
        def search_by_key(key):
            for ele in saudi_fdi_subreddit:
                subreddit = reddit.subreddit(ele)
                type_posts = subreddit.search(key, limit=None, sort='relevance', time_filter='year')
                save_to_csv(type_posts, key)

        for words in FDI_keywords:
            search_by_key(words)