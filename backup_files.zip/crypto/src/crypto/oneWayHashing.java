package crypto;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class oneWayHashing
{
    public static void main(String[] args)
    {
        String s1 = "password";
        String s2 ="passwo";
        String result1 = getHash(s1);
        String result2 = getHash(s2);
        if(result1.equals(result2)) {
        	System.out.println("The strings are the same");
        }
        else {
        	System.out.println("The strings are not same");
        }
        
    }
    public static String getHash(String passwordToHash) {
    	String generatedPassword = null;
        try {
           
            MessageDigest md = MessageDigest.getInstance("MD5");
            
            md.update(passwordToHash.getBytes());
            
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
           
        }
        return generatedPassword;
        
    	
    }
}