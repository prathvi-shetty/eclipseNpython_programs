package com.demo.jdbc;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import org.omg.CORBA.portable.InputStream;

//package com.demo.jdbc;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//public class JDBCStep1 {
//	private static final String user = "postgres";
//	private static final String url = "jdbc:postgresql://127.0.0.1:5432/postgres";
//    private static final String password = "cliona";
//    public static void main(String[] args) {
//    	
//	try {
//		Connection con =DriverManager.getConnection(url,user,password);
//		System.out.println("Connected");
//	} catch (SQLException e) {
//		// TODO Auto-generated catch block
//		System.out.println("failed Connected");
//		e.printStackTrace();
//	}
//    }
//}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

class ConnectionPool {
	private List<Connection>availableConnections = new ArrayList<Connection>();
	private List<Connection>usedConnections = new ArrayList<Connection>();
	private final int MAX_NO = 5;
	
	private String url;
	private String user;
	private String password;
	
	public ConnectionPool(String url, String user, String password) throws SQLException {
		this.url = url;
		this.user = user;
		this.password = password;
		
		for(int i=0 ; i< MAX_NO; i++) {
			availableConnections.add(this.createConnection());
		}
	}
	
		private Connection createConnection() throws SQLException {
			
		  return DriverManager.getConnection(this.url, this.user, this.password);
	}
		public Connection getConnection() {
			if (availableConnections.size() == 0) {
				System.out.println("All connections are Used !!");
				return null;
			} else {
				Connection con = 
				availableConnections.remove(
					availableConnections.size() - 1);
				usedConnections.add(con);
				return con;
			}
		}



		/** Public function, to return connection back to the Pool **/
		public boolean releaseConnection(Connection con) {
			if (null != con) {
				usedConnections.remove(con);
				availableConnections.add(con);
				return true;
			}
			return false;
		}





		/** Utility function to check the number of Available Connections **/
		public int getFreeConnectionCount() {
			return availableConnections.size();
		}
	}





	/** Test Class for testing Connection Pool **/
	

	
	public class JDBCStep1 {

		public static void main(String[] args) throws SQLException {
			
			

			ConnectionPool pool
				 = new ConnectionPool("jdbc:postgresql://127.0.0.1:5432/images",
					"postgres","cliona");
//			Connection con1 = pool.getConnection();
//			Connection con2 = pool.getConnection();
//			System.out.println(pool.getFreeConnectionCount());
//			Connection con3 = pool.getConnection();
//			Connection con4 = pool.getConnection();
//			Connection con5 = pool.getConnection();
//			Connection con6 = pool.getConnection();
//			System.out.println(pool.getFreeConnectionCount());
//			pool.releaseConnection(con1);
//			pool.releaseConnection(con2);
//			pool.releaseConnection(con4);
			Connection con1 = pool.getConnection();
			BufferedImage originalImage = null;
			try {
				originalImage = ImageIO.read(new File(
						"D:\\download.png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			originalImage= rotateClockwise90(originalImage);
			
			
			try (PreparedStatement stmt = con1.prepareStatement("insert into pictures (img) values (?)")) {
			    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
			        ImageIO.write(originalImage, "png", baos);
			        try (ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray())) {
			            stmt.setBinaryStream(1, bais);
			            int rows = stmt.executeUpdate();
			            System.out.println(rows + " rows updated");
			        }
			    }
			} catch (SQLException | IOException exp) {
			    exp.printStackTrace();
			
		}
			try (PreparedStatement stmt = con1.prepareStatement("select img from pictures")) {
			    try (ResultSet rs = stmt.executeQuery()) {
			        while (rs.next()) {
			            try (java.io.InputStream is = rs.getBinaryStream(1)) {
			                BufferedImage img = ImageIO.read(is);
			                ImageIO.write(img, "png", new File(
			    					"D:\\download3.png"));
			            }
			        }
			    }
			} catch (SQLException | IOException exp) {
			    exp.printStackTrace();
			}
			
			System.out.println(pool.getFreeConnectionCount());
		
		}
		public static BufferedImage rotateClockwise90(BufferedImage src) {
		    int width = src.getWidth();
		    int height = src.getHeight();

		    BufferedImage dest = new BufferedImage(height, width, src.getType());

		    Graphics2D graphics2D = dest.createGraphics();
		    graphics2D.translate((height - width) / 2, (height - width) / 2);
		    graphics2D.rotate(Math.PI / 2, height / 2, width / 2);
		    graphics2D.drawRenderedImage(src, null);

		    return dest;
		
	}
	}
	
	



