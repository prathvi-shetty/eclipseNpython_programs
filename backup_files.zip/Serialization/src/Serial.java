import java.io.*;

public class Serial implements Serializable{

	public int n;
	public String str;
	public  Serial(int n, String st)
	{
		this.n = n ;
		this.str = st;
	}
}
 
class Test{
	public static void main(String[] args ) {
		String files = "file.ser";
		Serial ser = new Serial(5,"Cilona");
		try 
		{
		FileOutputStream file = new FileOutputStream(files);
		ObjectOutputStream out = new ObjectOutputStream(file);
		out.writeObject(ser);
		out.close();
		file.close();
		System.out.println("serialized");
		}
		catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
		
	}
}
