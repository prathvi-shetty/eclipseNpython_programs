# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 16:07:57 2019

@author: prathvi.shetty
"""
import configparser
config = configparser.ConfigParser()
config.read('example.ini')
x = config['news']['password']
print(x)