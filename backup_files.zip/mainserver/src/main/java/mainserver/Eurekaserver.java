package mainserver;

public class Eurekaserver {

}
