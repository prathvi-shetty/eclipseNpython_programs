import luigi
import pandas as pd
import nltk
import re
import spacy
from sklearn.feature_extraction.text import CountVectorizer
from datetime import datetime
nlp = spacy.load('en_core_web_sm')
stop = nltk.corpus.stopwords.words('english')

from add import Add
class Print(luigi.Task):
    def requires(self):
        return  Add()
    def output(self):
        return luigi.LocalTarget('infile_trial.csv')
    def run(self):
        with self.input().open('r') as infile:
            tweet_df = pd.read_csv(infile, encoding="ISO-8859-1")
            tweet_df.index.name = 'index'
            tweet_df.to_csv('infile_trial.csv', header=True, index=True)
            tweet_df = pd.read_csv('infile_trial.csv', encoding="ISO-8859-1")

            def lemm(text):
                text_final = " "
                word1 = nlp(text)
                for token in word1:
                    if token.lemma_ == "-PRON-":
                        text_final += token.text + " "
                    else:
                        text_final += token.lemma_ + " "
                return text_final

            def tokenization(text):
                text = re.split('\W+', text)
                return text

            def stopwords(text):
                text = [word for word in text if word not in stop]
                return text

            def getDiffBetweenDates(a, b):
                print(a)
                print(b)
                firstDate = datetime.strptime(a, '%m/%d/%Y')
                print(firstDate)
                lastDate = datetime.strptime(b, '%Y-%m-%d')
                print(lastDate)
                diff = firstDate - lastDate
                return diff.days

            def y(x):
                score = 0
                x = str(x)
                x = x.replace('[', '').replace(']', '').replace("'", '')
                l = list(x.split(","))
                for i in l:
                    i = i.replace(' ', '')
                    i.replace(' ', '')
                    value = dictionary.get(i)
                    if value is None:
                        continue
                    else:
                        score += value
                return score

            def get_range(x, y):

                if x > 0.9 * y:
                    return 5
                elif x > 0.8 * y:
                    return 4.5
                elif x > 0.7 * y:
                    return 4
                elif x > 0.6 * y:
                    return 3.5
                elif x > 0.5 * y:
                    return 3
                elif x > 0.4 * y:
                    return 2.5
                elif x > 0.3 * y:
                    return 2
                elif x > 0.2 * y:
                    return 1.5
                elif x > 0.1 * y:
                    return 1
                elif x > 0.05 * y:
                    return 0.5
                else:
                    return 0.25

            total_rows = len(tweet_df)

            def rowNumber(i):
                if i >= 0.9 * total_rows:
                    return 10
                elif i >= 0.8 * total_rows:
                    return 9
                elif i >= 0.8 * total_rows:
                    return 8
                elif i >= 0.7 * total_rows:
                    return 7
                elif i >= 0.6 * total_rows:
                    return 6
                elif i >= 0.5 * total_rows:
                    return 5
                elif i >= 0.4 * total_rows:
                    return 4
                elif i >= 0.3 * total_rows:
                    return 3
                elif i >= 0.2 * total_rows:
                    return 2
                elif i >= 0.1 * total_rows:
                    return 1
                else:
                    return 0

            tweet_df1 = pd.DataFrame()
            tweet_df1['lemmatized'] = tweet_df['title'].apply(lambda x: lemm(x))
            tweet_df1['tokenized'] = tweet_df1['lemmatized'].apply(lambda x: tokenization(x.lower()))
            tweet_df1['stopwordized'] = tweet_df1['tokenized'].apply(lambda x: stopwords(x))

            comment_words = ' '
            for val in tweet_df1.stopwordized:
                val = str(val)
                tokens = val.split()
                for words in tokens:
                    comment_words = comment_words + words + ' '

            new = comment_words.replace(',', '')
            new = new.replace('] [', '],[')
            new = new.replace("'", '')
            new2 = [new]

            vectorizer = CountVectorizer()
            word_count_vector = vectorizer.fit_transform(new2)
            word_list = vectorizer.get_feature_names();
            count_list = word_count_vector.toarray().sum(axis=0)
            dictionary = dict(zip(word_list, count_list))

            tweet_df['Keyword_Frequency_Score'] = tweet_df1['stopwordized'].apply(lambda x: y(x))

            def votesFunc(i):
                return votesList[i]

            def releScoreFunc(i):
                return releScoreList[i]

            def month(i):
                return monthsList[i]

            votesList = []
            releScoreList = []
            monthsList = []

            for i in tweet_df.itertuples():
                upvotes = i[3]
                downvotes = ((100 * i[3]) / i[4]) - i[3]
                votes = upvotes + downvotes
                votesList.append(votes)

            tweet_df['votes'] = tweet_df['index'].apply(lambda x: votesFunc(x))
            max_votes = tweet_df['votes'].max()
            max_num_comments = tweet_df['num_comments'].max()

            for i in tweet_df.itertuples():
                print(type(i[8]))
                c = str(i[8])
                # y = datetime.strptime(c, '%m-%d-%Y')
                x = getDiffBetweenDates(datetime.today().strftime('%m/%d/%Y'), c)
                months = (x / 30) + 1
                monthsList.append(months)
                range_votes = get_range(i[14], max_votes)
                range_comments = get_range(i[7], max_num_comments)
                relevancy_score = (i[13] * range_votes * range_comments) / months
                releScoreList.append(relevancy_score)

            tweet_df['Months_since_post'] = tweet_df['index'].apply(lambda x: month(x))
            tweet_df['Relevancy_Score'] = tweet_df['index'].apply(lambda x: releScoreFunc(x))

            sort_by_life = tweet_df.sort_values('Relevancy_Score')
            sort_by_life.to_csv('infile_trial.csv', header=True, index=False)

            tweet_df = pd.read_csv('infile_trial.csv', encoding="ISO-8859-1")
            tweet_df.index.name = 'RowNo'
            tweet_df.to_csv('infile_trial.csv', header=True, index=True)
            tweet_df = pd.read_csv('infile_trial.csv', encoding="ISO-8859-1")

            tweet_df['RelIndex'] = tweet_df['RowNo'].apply(lambda x: rowNumber(x))
            tweet_df.to_csv('infile_trial.csv', header=True, index=False)
