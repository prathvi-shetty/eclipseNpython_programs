
public class prime {
	
}
