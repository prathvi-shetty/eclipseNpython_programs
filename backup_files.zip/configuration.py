# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 16:09:42 2019

@author: prathvi.shetty
"""

import configparser
config = configparser.ConfigParser()
config['news']={}
config['news']['api_key']= 'da6ba99c77e74a34a2eed9d8f9f90871'
with open('configuration.ini','w') as configfile:
    config.write(configfile)