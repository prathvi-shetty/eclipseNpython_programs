from json import dumps
from time import sleep
from kafka import KafkaConsumer
from flask_cors import CORS, cross_origin
from kafka import KafkaProducer
from flask import Flask, jsonify,request, make_response
import datetime
from functools import wraps
import jwt
import os
import subprocess
app = Flask("__main__")
CORS(app)

keywords = []
app.config['SECRET_KEY'] = 'secret'

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.args.get('token')
        if not token:
            return jsonify({'message': 'token is missing'}),403
        try:
            data =jwt.decode(token, app.config['SECRET_KEY'])
        except:
            return jsonify({'message' : 'Token is invalid !'}),403
        return f(*args,**kwargs)
    return decorated



@app.route('/api', methods=['POST', 'GET'])
@cross_origin()
@token_required
def api_post():
    if request.method == 'POST':
        global keywords
        print('post app')

        req = request.args['keyword']
        sources = request.args['sources']
        print(sources)
        source_list = sources.split(',')
        print(source_list)
        print(type(source_list))

        '''' inp = request.args['input']'''
        '''producer = KafkaProducer(bootstrap_servers=['localhost:9092'],
                                 value_serializer=lambda x:
                                 dumps(x).encode('utf-8'))
        producer.send('keyword', value= req)'''
        print(req)
        print(type(sources))
        for i in source_list:
            if 'twitter' in i:
                print(i)
                os.system("python -m luigi --module twitterProcessing Processing --keyword " + req + " --local-scheduler")
            elif 'news' in i:
                print('news')
                os.system("python -m luigi --module newsProcessing Processing --keyword " + req + " --local-scheduler")
            elif 'reddit' in i:
                print('Reddit')
                subprocess.call("python -m luigi --module reddit_preprocessing Processing --keyword " + req + " --local-scheduler")

        # if 'twitter' in sources:
        #     os.system("python -m luigi --module twitterProcessing Processing --local-scheduler")
        # elif 'news' in sources:
        #     print(req, 'request')
        #     #os.system("python -m luigi --module newsProcessing Processing --keyword   --n 5 --local-scheduler")
        #     subprocess.call("python -m luigi --module newsProcessing Processing --keyword "+ req +" --n 5 --local-scheduler")
        # elif 'reddit' in sources:
        #     print('reddit')

        keywords.append(req)
        with open("configuration.ini", "a") as output:
            output.write("keyword = "  + str(keywords))
        return req

@app.route('/run', methods=['POST', 'GET'])
@cross_origin()
def run_luigi():
    os.system("python -m luigi --module newsProcessing Processing --local-scheduler")
    return jsonify({'token': 'tok'})

@app.route('/runtwitter', methods=['POST','GET'])
@cross_origin()
def run_luigi_twitter():
    os.system("python -m luigi --module twitterProcessing Processing --local-scheduler")
    return jsonify({'token' : 'tok'})


@app.route('/getdate',methods=['POST'])
@cross_origin()
@token_required
def api_posts():
    if request.method == 'POST':
        data = request.get_json()
        start = data['startDate']
        print(start)
    return jsonify({'token': 'tok'})


@app.route('/authenticate',methods=['POST'])
@cross_origin()
def authenticate():
    print('hit the authenticate AP')
    if request.method == 'POST':
        uid = request.args['uid']
        name = request.args['name']
        token = jwt.encode({'user': name, 'id':uid}, app.config['SECRET_KEY'])
        return jsonify({'token': token.decode('UTF-8')})


app.run(host='0.0.0.0', port="5000")