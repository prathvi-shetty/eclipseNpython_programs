
//import java.util.Scanner;
//public class prog1 {
//	public static void main(String[] args) {
//		
//		int x = 5;
//	//	 System.out.println(x == 5 ? "its 5" : "not");
//		 //Enhanced for loop
//		/* int[] arr = {1,2,2,5,3};
//		 for (int i : arr)
//		 {
//			 System.out.println(i);
//		 }*/
//		
//		boolean var = isprime(24);
//		if(var == true) {
//			System.out.println("is prime");
//		}
//		else {
//			System.out.println("is not prime");
//		}
//		
//	
//
//}
//	public static boolean isprime (int a)
//	{
//	int i;
//	for(i=2; i< a/2 ;i++) {
//		if(a % i == 0)
//		{
//			return false;
//			
//		}
//	}
//	return true;
//	}
//	 
//}

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;


 
public class prog1{
	public static void main(String[] args ) {
		String files = "file.ser";
		Serial ser = new Serial(5,"Cilona");
		try 
		{
		FileOutputStream file = new FileOutputStream(files);
		ObjectOutputStream out = new ObjectOutputStream(file);
		out.writeObject(ser);
		out.close();
		file.close();
		System.out.println("serialized");
		}
		catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
		
	}
}


 class Serial implements Serializable{

	public int n;
	public String str;
	public  Serial(int n, String st)
	{
		this.n = n ;
		this.str = st;
	}
}

