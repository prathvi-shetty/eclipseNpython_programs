package java_prepare;

public class exeint {
	 
    public void getStringBufferPerformance() {
 
        StringBuffer strBufferOne = new StringBuffer();
        long startTime = System.currentTimeMillis();
        for (int i = 1; i <= 100000; i++) {
            strBufferOne.append("o");
            strBufferOne.append(" ");
            strBufferOne.append(i);
            strBufferOne.append(" ");
        }
 
        System.out.println("Time Taken by StringBuffer is: " + (System.currentTimeMillis() - startTime) + " ms");
      System.out.println(strBufferOne);
 
    }
 
    public void getStringBuilderPerformance() {
 
        StringBuilder strBuilderOne = new StringBuilder();
        long startTime = System.currentTimeMillis();
        for (int i = 1; i <= 100000; i++) {
            strBuilderOne.append(i);
            strBuilderOne.append(" ");
            strBuilderOne.append(i);
            strBuilderOne.append(" ");
        }
 
        System.out.println("Time Taken by StringBuilder is: " + (System.currentTimeMillis() - startTime) + " ms");
       System.out.println(strBuilderOne);
 
    }
    public static void main(String[] args) {
 
    	exeint obj = new exeint();
        obj.getStringBufferPerformance();
        obj.getStringBuilderPerformance();
    }
 
}