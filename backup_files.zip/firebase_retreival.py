
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

config = {
  "type": "service_account",
  "project_id": "authentication-4a3c1",
  "private_key_id": "a5411c5bebf04df973d6c843959719d46c010fb2",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCmFOj+b+TnZ/B2\n5fS+EyMbvcr7YmDMcf/Q3b2X6O0tfA8oEMWYXoOzqmCCu2PIQtl144QGDnsg2seK\nW2ZSHtSt4De2z1ZYBadaYrSRNw+VibTrfvimlaP8osVuXZyrjLzuVtNRVFfXdiJY\nufBl+FMRIgM1o7Z+DJXtIwWYxMwAlSK/b6MgDR56RR0HeifGDKnnPgy9N6iaPcZc\n1v0sxFgQ2lT8A+/0AQxrbPbANAS19dPptn8fZJyNCai6fRIoqceqr/kFksK3fgR4\ngkD1tPn0IeHFC4CyX+BFKkUeLTAbHArjuV703NqnzC1B6T01ogxB0HGYk6Q+fqAx\nFRd7KDZ7AgMBAAECggEAQjBKLQDeCqU/TbtWnxvUXZ11lFsANepm59A/W5fOUlbD\nWZXZkeB0/3jyzpcs7KZLsTJzrtA9nPnkFU1YyXiVDRizS411HU5fhGObD9aQROnl\nKwdmxEkV2jzqjxIKusmzkA8VV6/T9EAV7yNnXdQqEsVp3wo4VCLi62eONvSTUtV4\nJ7UmD1e+nkepCZSLdz9uNn7HhHY4jXnLNDH2mTxKaefkVbOkfMcM09evjXanfsmU\nkehSntqW9MuUqJoC5z3ZV4dgAayoGWblWmFu1Ko8vSqQ5gPeU40WKsi8U3HhyBm+\nlGYUiJsn1o4E4tvJLSsvSfR51zGdhCYefmAANS6ISQKBgQDaymtGlPyNzmLW4vR3\n6Iw6NQZGwLukrW6dAajpk9ivhPSJckIZ9/Rhe3/bL2OOqksdc4rF/06eYaxylfZT\nP3NLbgEupClZpFoSMrUpOOB0DNZYotVj7W4YzJQIhTGiexxyrnjnJhnaQ8Tno3jU\nEgRZa+QdnemROEkO/1TFk86JQwKBgQDCU61Ay5l+ARcgGIoCTDhi0VexGNF0Z6hY\njiknQJSz/N8VZrKO9Do/nK6dTTEdKpM4URA9UPG5bYYUSBvlFJO3V1c2xk09Abkl\nnXF049MfVPm93qWrZDboKkdke6KMdDIBuDU2L1a5oHr+ZIpBwdj7tpNO3vS8K7VZ\nAeVEDCrOaQKBgQCHJJsoyORLL11sAFojKthbJ9+NmoUNTjdR8fGE/dbNa+GkeJgN\n9FPWVvN9zwK+379wHKtua6oDOK/NQ4YYm8u6nuNKDQqhnVwpe3rdUI2MAVXw//ux\nMrpbxRn3PVaQV10WFWEG3kj/wfaBYj9DNzHKjlMkXCMmmU6/XcXeGNNtgwKBgE9e\n/hTJFBhzOY7SdwwZNa6m8rpS+Loi3I/PAOAXcKVTU4raN3RMLL5usKNvM/BFw3vt\nIETrGtAx++Gs0jfu/6aS9fxZYpLYcVb7x6uGomTZwGfc2K34cLTDEAXquanEi+hH\n5PQMwc9vzMy7I/1Xv9iP6fr89dklwRxpucrhbVqBAoGBAJxMfknPtB1Sid1FpAsA\nhfr+GE/sg8vROHThKCf1CqRCx1l5t+J+kFkh+TqcYAV5wBYoUq9/2sDOBM6950Uz\n7w/Qfci28te745D2pF9TRylZwgPQkY0zXHbXtEF2LtAwuTGny3Xr19vQLl9/H2cg\nzBLAg7iLhJ7ifj8Yv2h952mJ\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-prb1j@authentication-4a3c1.iam.gserviceaccount.com",
  "client_id": "117313699919362373484",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-prb1j%40authentication-4a3c1.iam.gserviceaccount.com"
}

cred = credentials.Certificate(config)


firebase_admin.initialize_app(cred, {'databaseURL': 'https://authentication-4a3c1.firebaseio.com'})

ref = db.reference('users').get()
#iterating  through the list
print(type(ref))
for i in ref.values():
    status = i.get("status")
    if status == 'Initiated':
        print('not yet started')
    else:
        print('started')



print(ref)