package testing;

public class sum {
	public static int sum(int a, int b) {
		int s= a+b;
		return s;
		
	}
public static boolean cmp(String str1, String str2) {
	if(str1.equals(str2)) {
		return true;
	}
	else {
		return false;
	}
	
}
	public static void main(String args[]) {
		int p = sum(9,12);
		String a="hello";
		String b= "helloo";
		boolean x = cmp(a,b);
		if(x) {
			System.out.println("equal");
		}
		else {
			System.out.println("not equal");
		}
		System.out.println(p);
	}

}
